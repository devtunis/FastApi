import React, { useState } from "react";
import "./Register.css";
import axios from "axios";
import { UUID } from "../../utils/randochr";
import { useNavigate } from "react-router";

const Register = () => {
  const [fullname, Setfullname] = useState("");
  const [email, Setemail] = useState("");
  const [password, Setpassword] = useState("");
  const Route = useNavigate();

  const HandelRegister = async () => {
    try {
      const data = await axios.post("http://127.0.0.1:8000/register", {
        uuid: UUID(),
        name: fullname,
        email: email,
        password: password,
      });

      if (data) {
        Route("/login");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="register-root">

      {/* LEFT SIDE (branding) */}
      <div className="register-left">
        <div className="left-content">
          <h1>Join Us</h1>
          <p>Start your journey with a modern experience</p>

          <div className="floating-shape shape1"></div>
          <div className="floating-shape shape2"></div>
        </div>
      </div>

      {/* RIGHT SIDE (form) */}
      <div className="register-right">

        <div className="register-card">

          <h2>Create Account</h2>
          <span className="sub">It takes less than a minute</span>

          <div className="input-group">
            <input
              type="text"
              placeholder="Full Name"
              onChange={(e) => Setfullname(e.target.value)}
            />
          </div>

          <div className="input-group">
            <input
              type="text"
              placeholder="Email"
              onChange={(e) => Setemail(e.target.value)}
            />
          </div>

          <div className="input-group">
            <input
              type="password"
              placeholder="Password"
              onChange={(e) => Setpassword(e.target.value)}
            />
          </div>

          <div className="terms">
            <input type="checkbox" />
            <span>I agree to terms</span>
          </div>

          <button onClick={HandelRegister} className="register-btn">
            Create Account
          </button>

          <div className="divider">
            <span></span>
            <p>or</p>
            <span></span>
          </div>

          <div className="social">
            <button>Google</button>
            <button>GitHub</button>
          </div>

          <div className="bottom">
            Already have account ? {" "}
            <span onClick={() => Route("/login")}>Login</span>
          </div>

        </div>

      </div>
    </div>
  );
};

export default Register;