import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import axios from "axios";
import Loader1 from "../../Loader/Loader1";
import Addmembers from "../addmembers/Addmembers";
import "./Dashboard.css";
import {
  LayoutGrid, Users, Calendar, MessageCircle, TrendingUp,
  Plus, Bell, Search, LogOut, BookOpen
} from "lucide-react";

const Dashboard = () => {
  const Nav = useNavigate();

  useEffect(() => {
    if (!localStorage.getItem("profile")) Nav("/login");
  }, []);

  const [activeTab, setActiveTab] = useState("overview");
  const [groups, setGroups] = useState([]);
  const [show, setShow] = useState(false);
  const [userSelected, setUserSelected] = useState({ data: null });
  const [profile] = useState(() => JSON.parse(localStorage.getItem("profile")));

  useEffect(() => {
    const fetch = async () => {
      try {
        const { data } = await axios.get(`http://127.0.0.1:8000/getfollwgroups/${profile.uuid}`);
        setGroups(data);
      } catch (e) { console.log(e); }
    };
    fetch();
  }, []);

  const handleInvite = (data) => {
    setUserSelected({ data });
    setShow(true);
  };

  const kpis = [
    { label: "Study Groups", value: groups.length || "—", change: "+2 this week", color: "#a78bfa" },
    { label: "Sessions", value: "12", change: "Next: Today 3PM", color: "#34d399" },
    { label: "Messages", value: "24", change: "3 groups active", color: "#f472b6" },
    { label: "Progress", value: "78%", change: "+12% this month", color: "#60a5fa" },
  ];

  const sessions = [
    { id: 1, topic: "Calculus Integration", group: "Advanced Mathematics", day: "Today", time: "3:00 PM", status: "upcoming" },
    { id: 2, topic: "Data Structures", group: "Computer Science", day: "Tomorrow", time: "2:00 PM", status: "upcoming" },
    { id: 3, topic: "Quantum Mechanics", group: "Physics Study Group", day: "Friday", time: "4:00 PM", status: "scheduled" },
  ];

  const activity = [
    { id: 1, user: "Sarah Johnson", action: "completed topic assignment", group: "Advanced Mathematics", time: "2h ago", color: "#a78bfa" },
    { id: 2, user: "Mike Chen", action: "scheduled a new session", group: "Computer Science", time: "4h ago", color: "#34d399" },
    { id: 3, user: "Emma Wilson", action: "joined the group", group: "Literature Review", time: "5h ago", color: "#f472b6" },
    { id: 4, user: "David Brown", action: "shared study materials", group: "Physics Study Group", time: "Yesterday", color: "#fbbf24" },
  ];

  const dotColors = ["#a78bfa", "#34d399", "#f472b6", "#fbbf24", "#60a5fa"];

  return (
    <div className="db-shell">
      {/* Icon Rail */}
      <nav className="db-rail">
        <div className="db-logo">
          <BookOpen size={18} color="white" />
        </div>
        <button className={`db-rail-btn ${activeTab === "overview" ? "on" : ""}`} onClick={() => setActiveTab("overview")}><LayoutGrid size={20} /></button>
        <button className={`db-rail-btn ${activeTab === "groups" ? "on" : ""}`} onClick={() => { setActiveTab("groups"); Nav("/Mygroups"); }}><Users size={20} /></button>
        <button className={`db-rail-btn ${activeTab === "sessions" ? "on" : ""}`} onClick={() => { setActiveTab("sessions"); Nav("/sessionlist"); }}><Calendar size={20} /></button>
        <button className={`db-rail-btn ${activeTab === "chat" ? "on" : ""}`} onClick={() => setActiveTab("chat")}><MessageCircle size={20} /></button>
        <div className="db-rail-spacer" />
        <button className="db-rail-btn logout" onClick={() => { Nav("/login"); localStorage.clear(); }}><LogOut size={18} /></button>
        <div className="db-rail-avatar">{profile?.name?.charAt(0)?.toUpperCase() || "U"}</div>
      </nav>

      {/* Main */}
      <div className="db-main">
        {/* Top bar */}
        <header className="db-topbar">
          <div className="db-search">
            <Search size={15} className="db-search-icon" />
            <input placeholder="Search groups, sessions, members…" />
          </div>
          <div className="db-tb-right">
            <button className="db-notif">
              <Bell size={16} />
              <span className="db-badge">5</span>
            </button>
            <div>
              <div className="db-tb-name">{profile?.name}</div>
              <div className="db-tb-role">Student</div>
            </div>
          </div>
        </header>

        <div className="db-scroll">
          {/* Hero */}
          <div className="db-hero">
            <h1>Good afternoon, {profile?.name?.split(" ")[0]} 👋</h1>
            <p>You have 3 sessions today and 24 unread messages.</p>
          </div>

          {/* KPIs */}
          <div className="db-kpis">
            {kpis.map((k, i) => (
              <div className="db-kpi" key={i}>
                <div className="db-kpi-accent" style={{ background: k.color }} />
                <div className="db-kpi-label">{k.label}</div>
                <div className="db-kpi-val" style={{ color: k.color }}>{k.value}</div>
                <div className="db-kpi-sub">
                  <span style={{ background: k.color + "22", color: k.color }}>{k.change}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Quick actions */}
          <div className="db-quick">
            <button className="db-qbtn pri" onClick={() => Nav("/studygroup")}>
              <Plus size={15} /> New Study Group
            </button>
          
      
          </div>

          {/* Mid row */}
          <div className="db-mid">
            {/* Groups */}
            <div className="db-card">
              <div className="db-card-hd">
                <h2>Your Study Groups</h2>
                <button onClick={() => Nav("/Mygroups")}>View all</button>
              </div>
              {!Array.isArray(groups) ? (
                <div style={{ display: "flex", justifyContent: "center", padding: "40px 0" }}><Loader1 /></div>
              ) : groups.length === 0 ? (
                <p className="db-empty">No groups yet. Create one!</p>
              ) : (
                groups.map((g, i) => (
                  <div className="db-group-row" key={g.idgroup}>
                    <div className="db-g-dot" style={{ background: dotColors[i % dotColors.length] }} />
                    <div style={{ flex: 1 }}>
                      <div className="db-g-name">{g.name}</div>
                      <div className="db-g-meta">{g.datecreate}</div>
                    </div>
                    <div className="db-g-actions">
                      {g.idgroup === profile?.uuid && (
                        <button className="db-gbtn inv" onClick={() => handleInvite(g)}>Invite</button>
                      )}
                      <button className="db-gbtn join" onClick={() => Nav(`/mygroups/${g.identify}`)}>Join</button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Sessions */}
            <div className="db-card">
              <div className="db-card-hd">
                <h2>Upcoming Sessions</h2>
                <button>View calendar</button>
              </div>
              {sessions.map((s) => (
                <div className="db-sess-row" key={s.id}>
                  <div className="db-sess-ic" style={{ background: "#a78bfa22" }}>
                    <Calendar size={16} color="#a78bfa" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div className="db-sess-topic">{s.topic}</div>
                    <div className="db-sess-grp">{s.group}</div>
                  </div>
                  <div className="db-sess-time">{s.day}<br />{s.time}</div>
                  <button className={`db-sess-join ${s.status === "scheduled" ? "muted" : ""}`}>
                    {s.status === "upcoming" ? "Join" : "Details"}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom row */}
          <div className="db-bottom">
            {/* Activity */}
            <div className="db-card">
              <div className="db-card-hd"><h2>Recent Activity</h2><button>View all</button></div>
              {activity.map((a) => (
                <div className="db-act-row" key={a.id}>
                  <div className="db-act-av" style={{ background: a.color + "22", color: a.color }}>
                    {a.user.charAt(0)}
                  </div>
                  <div className="db-act-text">
                    <strong>{a.user}</strong> {a.action} in {a.group}
                  </div>
                  <div className="db-act-t">{a.time}</div>
                </div>
              ))}
            </div>

            {/* Progress */}
            <div className="db-card">
              <div className="db-card-hd"><h2>Your Progress</h2></div>
              <div className="db-prog-wrap">
                <div className="db-prog-main">
                  <div className="db-ring">
                    <svg viewBox="0 0 100 100" width="96" height="96">
                      <circle cx="50" cy="50" r="42" fill="none" stroke="#1e1e22" strokeWidth="8" />
                      <circle cx="50" cy="50" r="42" fill="none" stroke="#a78bfa" strokeWidth="8"
                        strokeLinecap="round" strokeDasharray="263.9"
                        strokeDashoffset={263.9 - (263.9 * 78) / 100}
                        style={{ transform: "rotate(-90deg)", transformOrigin: "50px 50px" }} />
                    </svg>
                    <div className="db-ring-pct">78%</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500, color: "#d5d5d5" }}>Overall progress</div>
                    <div style={{ fontSize: 12, color: "#555", marginTop: 4 }}>24 topics done · 8 active</div>
                  </div>
                </div>
                {[
                  { label: "Mathematics", val: 85, color: "#a78bfa" },
                  { label: "Computer Science", val: 72, color: "#34d399" },
                  { label: "Physics", val: 61, color: "#f472b6" },
                  { label: "Literature", val: 90, color: "#fbbf24" },
                ].map((b) => (
                  <div className="db-pb-row" key={b.label}>
                    <div className="db-pb-label"><span>{b.label}</span><span>{b.val}%</span></div>
                    <div className="db-pb-track"><div className="db-pb-fill" style={{ width: `${b.val}%`, background: b.color }} /></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {show && <Addmembers data={userSelected} fn={setShow} />}
    </div>
  );
};

export default Dashboard;