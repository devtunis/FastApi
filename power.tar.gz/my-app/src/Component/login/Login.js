import { useState } from "react"
import "./login.css"
import { useNavigate } from "react-router"
import axios from "axios"

const Login = () => {
    const nav = useNavigate()

    const [state, SetState] = useState({
        email: '',
        password: ''
    })

    const Handelsign = async () => {
        try {
            const { data } = await axios.post("http://127.0.0.1:8000/login", {
                email: state.email,
                password: state.password
            })

            if (data.message !== "Invalid email or password") {
                localStorage.setItem("profile", JSON.stringify(data))
                nav("/dashboard")
            }
        } catch (error) {
            console.log(error)
        }
    }

    return (
        <div className="login-root">

            <div className="login-card">

                {/* HEADER */}
                <div className="login-header">
                    <div className="logo-mark">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="12" r="6" stroke="white" strokeWidth="1.5"/>
                            <circle cx="12" cy="12" r="2" fill="white"/>
                        </svg>
                    </div>

                    <h1 className="login-title">Welcome back</h1>
                    <p className="login-subtitle">Login to your account</p>
                </div>

                {/* FORM */}
                <div className="login-form">

                    {/* EMAIL */}
                    <div className="field-group">
                        <label className="field-label">Email</label>

                        <div className="input-wrapper">
                            <svg className="input-icon" width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none">
                                <rect x="2" y="5" width="20" height="14" rx="2"/>
                                <path d="m2 7 10 6 10-6"/>
                            </svg>

                            <input
                                type="email"
                                placeholder="you@example.com"
                                className="login-input"
                                autoComplete="email"
                                onChange={(e) => SetState({
                                    ...state,
                                    email: e.target.value
                                })}
                            />
                        </div>
                    </div>

                    {/* PASSWORD */}
                    <div className="field-group">
                        <div className="label-row">
                            <label className="field-label">Password</label>
                            <span className="forgot-link">Forgot?</span>
                        </div>

                        <div className="input-wrapper">
                            <svg className="input-icon" width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none">
                                <rect x="3" y="11" width="18" height="10" rx="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>

                            <input
                                type="password"
                                placeholder="••••••••"
                                className="login-input"
                                autoComplete="current-password"
                                onChange={(e) => SetState({
                                    ...state,
                                    password: e.target.value
                                })}
                            />
                        </div>
                    </div>

                    {/* REMEMBER */}
                    <div className="remember-row">
                        <label className="checkbox-label">
                            <input type="checkbox" className="checkbox-input" />
                            <span className="checkbox-custom"></span>
                            <span className="checkbox-text">Remember me</span>
                        </label>
                    </div>

                    {/* BUTTON */}
                    <button className="login-btn" onClick={Handelsign}>
                        Sign in
                    </button>

                </div>

                {/* FOOTER */}
                <div className="login-footer">
                    <span>Don’t have an account ? </span>
                    <span className="signup-link" onClick={() => nav("/register")}>
                        Create one
                    </span>
                </div>

                {/* DIVIDER */}
                <div className="divider-row">
                    <span className="divider-line" />
                    <span className="divider-text">or</span>
                    <span className="divider-line" />
                </div>

                {/* SOCIAL */}
                <div className="social-row">
                    <button className="social-btn">Google</button>
                    <button className="social-btn">GitHub</button>
                </div>

            </div>
        </div>
    )
}

export default Login