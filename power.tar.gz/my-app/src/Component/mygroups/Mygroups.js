import { useNavigate, useParams } from "react-router";
import "./Mygroups.css";
import { useEffect, useState } from "react";
import axios from "axios";
import { time } from "../../utils/time";
import { ArrowLeft, Plus, Calendar, BookOpen, FileText, Clock, Trash2, Cone } from "lucide-react";

const dotColors = ["#a78bfa", "#34d399", "#f472b6", "#fbbf24", "#60a5fa"];

const Mygroups = () => {
  const Nav = useNavigate();
  const parms = useParams();

  useEffect(() => {
    if (!localStorage.getItem("profile")) Nav("/login");
  }, []);

  const [profile] = useState(() => JSON.parse(localStorage.getItem("profile")));
  const [session, setSession] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({ taskname: "", content: "" });

  useEffect(() => {
    axios.get(`http://127.0.0.1:8000/session/${parms.id}`)
      .then(({ data }) => setSession(data))
      .catch(console.log);
  }, []);

  useEffect(() => {
    axios.get(`http://127.0.0.1:8000/tasks/${parms.id}`)
      .then(({ data }) => { if (Array.isArray(data)) setTasks(data); })
      .catch(console.log);
  }, []);

  const handleCreate = async () => {
    if (!form.taskname || !form.content) return alert("Please fill all fields");
    try {
      const { data } = await axios.post(`http://127.0.0.1:8000/tasks`, {
        identify: session.identify,
        Date: time(),
        content: form.content,
        nametask: form.taskname,
      });
      if (data) {
        console.log(data,"<====")
        window.location.reload()
        // setTasks((prev) => [...prev, {
        //   identify: session.identify, Date: time(),
        //   content: form.content, nametask: form.taskname,
        // }]);
        setForm({ taskname: "", content: "" });
        setShow(false);
      }
    } catch (e) { console.log(e); }
  };

  const handleDelete = async (id, identify) => {
    try {
      const { data } = await axios.post(`http://127.0.0.1:8000/tasks/delete/${id}/${identify}`);
      if (data) setTasks(data.alltask);
    } catch (e) { console.log(e); }
  };

  return (
    <div className="mg-page">
      {/* Header */}
      <div className="mg-header">
        <div>
          <button className="mg-back" onClick={() => Nav(-1)}>
            <ArrowLeft size={14} /> Back to dashboard
          </button>
          <div className="mg-title-block">
            <h1>{session?.name || "Study Session"}</h1>
            <div className="mg-meta">
              <div className="mg-meta-pill"><Calendar size={13} />{session?.datecreate}</div>
              <div className="mg-meta-pill"><BookOpen size={13} />{session?.topic}</div>
              {session?.content && (
                <div className="mg-meta-pill"><FileText size={13} />{session.content}</div>
              )}
            </div>
          </div>
        </div>
        <button className="mg-add-btn" onClick={() => setShow(true)}>
          <Plus size={15} /> Add Task
        </button>
      </div>

      {/* Body */}
      <div className="mg-body">
        <div className="mg-section-label">Tasks · {tasks.length}</div>

        {tasks.length === 0 ? (
          <div className="mg-empty">
            <div className="mg-empty-icon"><FileText size={20} color="#333" /></div>
            <p>No tasks yet. Add one to get started.</p>
          </div>
        ) : (
          <div className="mg-grid">
            {tasks.map((task, i) => (
              <div className="mg-task" key={task.taskId}>
                <div className="mg-task-hd">
                  <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                    <div className="mg-dot" style={{ background: dotColors[i % dotColors.length] }} />
                    <div className="mg-task-name">{task.nametask}</div>
                  </div>
                  <button
                    className="mg-del"
                    onClick={() => handleDelete(task.taskId, task.identify)}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
                <div className="mg-task-content">{task.content}</div>
                <div className="mg-task-ft">
                  <Clock size={12} />
                  {task.Date}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal */}
      {show && (
        <div className="mg-overlay" onClick={(e) => e.target === e.currentTarget && setShow(false)}>
          <div className="mg-modal" onClick={(e) => e.stopPropagation()}>
            <h2>New task</h2>
            <div className="mg-field">
              <label>Task name</label>
              <input
                placeholder="e.g. Review chapter 5"
                value={form.taskname}
                onChange={(e) => setForm({ ...form, taskname: e.target.value })}
              />
            </div>
            <div className="mg-field">
              <label>Content</label>
              <textarea
                rows={3}
                placeholder="Describe what needs to be done…"
                value={form.content}
                onChange={(e) => setForm({ ...form, content: e.target.value })}
              />
            </div>
            <div className="mg-modal-actions">
              <button className="mg-cancel" onClick={() => setShow(false)}>Cancel</button>
              <button className="mg-submit" onClick={handleCreate}>Create task</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Mygroups;