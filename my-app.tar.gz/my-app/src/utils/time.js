 

export const time = () => {
     const  instance = new Date()
 

     return `${instance.getFullYear()}-${instance.getMonth()}-${instance.getDay()}-${instance.getMilliseconds()}`
  
 
}

 