export const randochr = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    return Array.from({ length: 15 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

export const UUID = () => {
    const digits = '0123456789';
    return parseInt(
        Array.from({ length: 5 }, () => digits[Math.floor(Math.random() * digits.length)]).join(''),
        10
    );
}