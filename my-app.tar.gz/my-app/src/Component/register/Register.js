import React, { useState } from "react";
import "./Register.css";
import axios from "axios" 
import {  UUID } from "../../utils/randochr";
import { useNavigate } from "react-router";
const Register = () => {
  const [fullname ,Setfullname] = useState("")
  const [email ,Setemail] = useState("")
  const [password ,Setpassword] = useState("")
  const Route = useNavigate()
  const    HandelRegister = async()=>{
    console.log({fullname,email,password})
    try{
      const data = await axios.post("http://127.0.0.1:8000/register",{
        "uuid"  : UUID(), 
        "name"  : fullname,
        "email" :email,
        "password" :password,
        
         
      })
      if(data){
        console.log("we add you ")
        Route("/login")

      }

    }catch(error){
      console.log(error)
    }
  }
  
  return (
    <div className="register-page">
      <div className="register-container">

        <div className="register-icon">⬢</div>

        <h1>Create Account</h1>
        <p>Register to start your session</p>
 

          <div className="input-group">
            <label>Full Name</label>
            <input type="text"
            onChange={(e)=>Setfullname(e.target.value)} 
            placeholder="Enter your full name" className="input-box" />
          </div>

          <div className="input-group">
            <label>Email Address</label>
            <input type="text" 
            onChange={(e)=>Setemail(e.target.value)}
            placeholder="you@example.com" className="input-box" />
          </div>

          <div className="input-group">
            <label>Password</label>
            <input
            onChange={(e)=>Setpassword(e.target.value)}            
            type="text" placeholder="********" className="input-box" />
          </div>

        

          <div className="terms">
            <input type="checkbox" id="terms" />
            <label htmlFor="terms">I agree to Terms & Conditions</label>
          </div>

          <button className="register-btn" onClick={()=>HandelRegister()}>Create Account →</button>

         

        <div className="divider">or continue with</div>

        <div className="social-login">
          <button>Google</button>
          <button>GitHub</button>
        </div>

        <div className="bottom-text">
          Already have an account? <a href="/login">Sign in</a>
        </div>

      </div>
    </div>
  );
};

export default Register;