import { useState } from "react";
import "./Mygroupsession.css";
import { useParams } from "react-router";

const Mygroupsession = () => {
  const [comment, setComment] = useState("");
  const parmas = useParams()
  console.log(parmas,"<==")
  const [group] = useState({
    name: "Advanced Mathematics",
    subject:
      "This class focuses on advanced calculus. Complete assigned exercises before each session and be ready to discuss solutions in class. Collaboration is encouraged, but each student must submit individual work.",
  });

  const [posts] = useState([
    {
      id: 1,
      user: "Sarah Johnson",
      message: "Don’t forget to revise integration techniques before tomorrow.",
      time: "2h ago",
    },
    {
      id: 2,
      user: "Mike Chen",
      message: "Does anyone understand substitution method? I’m stuck on question 3.",
      time: "5h ago",
    },
    {
      id: 3,
      user: "Emma Wilson",
      message: "I uploaded practice exercises in the materials section.",
      time: "Yesterday",
    },
  ]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!comment.trim()) return;
    console.log("New comment:", comment);
    setComment("");
  };

  return (
    <div className="classroom-page">

      {/* CLASS HEADER */}
      <div className="class-banner">
        <h1>{group.name}</h1>
      </div>

      {/* CLASS INFO CARD */}
      <div className="class-info-card">
        <h2>Class Description</h2>
        <p>{group.subject}</p>
      </div>

      {/* ADD COMMENT BOX */}
      <form className="comment-box" onSubmit={handleSubmit}>
        <div className="avatar">Y</div>
        <input
          type="text"
          placeholder="Add class comment..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
        <button type="submit">Post</button>
      </form>

      {/* POSTS */}
      <div className="stream">
        {posts.map((post) => (
          <div className="post" key={post.id}>
            <div className="post-left">
              <div className="avatar">{post.user.charAt(0)}</div>
            </div>

            <div className="post-content">
              <div className="post-header">
                <span className="name">{post.user}</span>
                <span className="time">{post.time}</span>
              </div>
              <p className="message">{post.message}</p>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};

export default Mygroupsession;