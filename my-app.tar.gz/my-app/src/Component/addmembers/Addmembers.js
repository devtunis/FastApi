import axios from "axios";
import "./Addmembers.css";
import {   useEffect, useState } from "react";
import { useNavigate } from "react-router";
 
const Addmembers = ({data,fn}) => {
  const [members] = useState([
    { id: 1, name: "John Doe", avatar: "JD" },
    { id: 2, name: "Sarah Johnson", avatar: "SJ" },
    { id: 3, name: "Mike Chen", avatar: "MC" },
    { id: 4, name: "Emma Wilson", avatar: "EW" },
    { id: 5, name: "David Brown", avatar: "DB" },
  ]);
  const Nav = useNavigate()
  const [users,SetUsers] = useState([])
  const [profile] = useState(()=>JSON.parse(localStorage.getItem("profile")))
   useEffect(()=>{
    const dat = localStorage.getItem("profile")
    if(!dat){
      Nav("/register")
    }
   },[])
  useEffect(()=>{
    const fetchUsers = async()=>{
      try{ 
        const {data} = await axios.get("http://127.0.0.1:8000/users")
        if(data){
          console.log(data.users)
          SetUsers(data.users)
        }  

      }catch(err){
        console.log(err)
      }
    }
    fetchUsers()
  },[])

  const handleInvite = async(id) => {
    console.log(`id: ${id}`);
 
    console.log(id, data.data.idgroup,data.data.identify)
 
 
    try{

      
    const  instance = new Date()
      const datex = `${instance.getFullYear()}-${instance.getMonth()}-${instance.getDay()}-${instance.getMilliseconds()}`
     const addingyou = await axios.post("http://127.0.0.1:8000/addMember",{
        "userid": id, 
        "groupid": data.data.idgroup  ,
        "identify" :data.data.identify,
        "Date" : datex
    })
    if(addingyou){
      console.log("succes adding ")
    }
    }catch(err)
    {
      console.log(err)
    }
  };

  return (
    <>
    
   
    <div className="addmembers-container">
       <button
       onClick={()=>fn(false)}
       style={{position:"absolute",top:"0",right:"0",background:"red",padding:"18px",borderRadius:"100%",marginRight:"5px",marginTop:"10px",cursor:"pointer"}}></button>
      <div className="addmembers-card">
        <h1>Add Members</h1>
        <p>Select users to invite to your study group</p>

        <div className="members-list">
          { users &&  users.filter((item)=>item.uuid!=profile.uuid)
          .map((member) => (
           
            <div key={users.uuid} className="member-item">
              <div className="member-left">
                <div className="avatar">{member.name[0]}</div>
                <span className="member-name">{member.name}</span>
              </div>

              <button
                className="invite-btn"
                onClick={() => handleInvite(member.uuid)}
              >
                Invite
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
        </>
  );
};

export default Addmembers;