import { useState } from "react";
import "./CreateSchedulesess.css";

const CreateSchedulesess = () => {
  const [form, setForm] = useState  ({
    title: "",
    date: "",
    time: "",
    location: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Session Scheduled:", form);
    alert("Study Session Scheduled Successfully!");
  };

  return (
    <div className="schedule-container">
      <form className="schedule-card" onSubmit={handleSubmit}>
        <h1>Schedule Study Session</h1>
        <p>
          planifiez des sessions d'étude en précisant la date, l'heure et le lieu
        </p>

        <label>Session Title</label>
        <input
          type="text"
          name="title"
          placeholder="e.g. calculus revision"
          value={form.title}
          onChange={handleChange}
          required
        />

        <label>Date</label>
        <input
          type="date"
          name="date"
          value={form.date}
          onChange={handleChange}
          required
        />

        <label>Time</label>
        <input
          type="time"
          name="time"
          value={form.time}
          onChange={handleChange}
          required
        />

        <label>Location</label>
        <input
          type="text"
          name="location"
          placeholder="e.g. library / zoom / room 204"
          value={form.location}
          onChange={handleChange}
          required
        />

        <button type="submit">schedule session</button>
      </form>
    </div>
  );
};

export default CreateSchedulesess ;