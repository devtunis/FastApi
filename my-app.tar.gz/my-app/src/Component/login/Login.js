import { useState } from "react"
import "./login.css"
import { useNavigate } from  "react-router"
 
import axios from "axios"
const Login = () => { 
    const nav = useNavigate()
    const [state,SetState] = useState({
        email : '',
        password : ''
    })
    const Handelsign = async ()=>{
       
   
        try{

            console.log(state.email)
            console.log(state.password)
        // nav("/dashboard") 
        const {data} = await axios.post("http://127.0.0.1:8000/login",{
            "email":state.email,
            "password":state.password
        })
        if(data.message!=="Invalid email or password"){
            console.log(data)
            localStorage.setItem("profile",JSON.stringify(data))
            nav("/dashboard") 
        }
        }catch(error){
            console.log(error)
        }
    }
    return (
        <div className="login-root">
            <div className="orb orb-1" />
            <div className="orb orb-2" />
            <div className="orb orb-3" />

            <div className="login-card">
                <div className="card-glow" />

                <div className="login-header">
                    <div className="logo-mark">
                        <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
                            <polygon points="18,2 34,10 34,26 18,34 2,26 2,10" fill="none" stroke="url(#hex-grad)" strokeWidth="2"/>
                            <polygon points="18,8 28,13 28,23 18,28 8,23 8,13" fill="url(#hex-fill)" opacity="0.3"/>
                            <circle cx="18" cy="18" r="4" fill="url(#hex-grad)"/>
                            <defs>
                                <linearGradient id="hex-grad" x1="2" y1="2" x2="34" y2="34" gradientUnits="userSpaceOnUse">
                                    <stop offset="0%" stopColor="#7eb8f7"/>
                                    <stop offset="100%" stopColor="#3a78d4"/>
                                </linearGradient>
                                <linearGradient id="hex-fill" x1="8" y1="8" x2="28" y2="28" gradientUnits="userSpaceOnUse">
                                    <stop offset="0%" stopColor="#7eb8f7"/>
                                    <stop offset="100%" stopColor="#3a78d4"/>
                                </linearGradient>
                            </defs>
                        </svg>
                    </div>
                    <h1 className="login-title">Welcome back</h1>
                    <p className="login-subtitle">Sign in to continue your session</p>
                </div>

                <div className="login-form">
                    <div className="field-group">
                        <label className="field-label" htmlFor="email">Email address</label>
                        <div className="input-wrapper">
                            <svg className="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="2" y="4" width="20" height="16" rx="2"/>
                                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                            </svg>
                            <input 
                            onChange={(e)=>SetState({
                                ...state,
                                email:e.target.value
                            })}
                            id="email" className="login-input" type="email" placeholder="you@example.com" autoComplete="email"/>
                        </div>
                    </div>

                    <div className="field-group">
                        <div className="label-row">
                            <label className="field-label" htmlFor="password">Password</label>
                            <a href="#" className="forgot-link">Forgot password?</a>
                        </div>
                        <div className="input-wrapper">
                            <svg className="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input 
                            onChange={(e)=>SetState({
                                ...state,
                                 password:e.target.value
                            })}
                            id="password" className="login-input" type="password" placeholder="••••••••••" autoComplete="current-password"/>
                        </div>
                    </div>

                    <div className="remember-row">
                        <label className="checkbox-label">
                            <input type="checkbox" className="checkbox-input"/>
                            <span className="checkbox-custom"/>
                            <span className="checkbox-text">Keep me signed in</span>
                        </label>
                    </div>

                    <button className="login-btn" type="button" onClick={()=>Handelsign()}>
                        <span className="btn-text" >Sign in</span>
                        <svg className="btn-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <path d="M5 12h14M12 5l7 7-7 7"/>
                        </svg>
                    </button>
                </div>

                <div className="login-footer">
                    <span>Don't have an account?</span>
                    <a href="#" className="signup-link" onClick={()=>nav("/register")}>Create one</a>
                </div>

                <div className="divider-row">
                    <span className="divider-line"/>
                    <span className="divider-text">or continue with</span>
                    <span className="divider-line"/>
                </div>

                <div className="social-row">
                    <button className="social-btn" type="button">
                        <svg width="18" height="18" viewBox="0 0 24 24">
                            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                        </svg>
                        Google
                    </button>
                    <button className="social-btn" type="button">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z"/>
                        </svg>
                        GitHub
                    </button>
                </div>
            </div>
        </div>
    )
}

export default Login
