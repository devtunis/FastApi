import { useEffect, useState } from "react";
import {
  Users,
  Calendar,
  MessageCircle,
  TrendingUp,
  Plus,
  Clock,
  BookOpen,
  CheckCircle,
  Menu,
  Bell,
  Search,
 
  LogOut,
} from "lucide-react";
import "./Dashboard.css";
import { useNavigate } from "react-router";
import axios from "axios";
import Loader1 from "../../Loader/Loader1";
import Addmembers from "../addmembers/Addmembers";

const Dashboard = () => {
 const Nav = useNavigate()

 
  useEffect(()=>{
    const data = localStorage.getItem("profile")
    if(!data){
      Nav("/login")
    }
  },[])
  const [activeTab, setActiveTab] = useState("overview");
  const [groupxx,Setgroup] = useState([])
  const [profile] = useState(()=>JSON.parse(localStorage.getItem("profile")))

  useEffect(()=>{
 
   const HandelFetchMySession =async () =>{
        try{
          const {data}  = await axios.get(`http://127.0.0.1:8000/getfollwgroups/${profile.uuid}`)
          console.log(data)
          Setgroup(data)
        }catch(error){
          console.log(error)
        }
   }
   HandelFetchMySession()
  },[])
  // Mock data
  const stats = [
    { icon: Users, label: "Study Groups", value: "8", change: "+2 this week" },
    { icon: Calendar, label: "Upcoming Sessions", value: "12", change: "Next: Today 3PM" },
    { icon: MessageCircle, label: "Unread Messages", value: "24", change: "3 groups active" },
    { icon: TrendingUp, label: "Progress", value: "78%", change: "+12% this month" },
  ];

  const studyGroups = [
    {
      id: 1,
      name: "Advanced Mathematics",
      members: 6,
      nextSession: "Today, 3:00 PM",
      progress: 85,
      color: "#3b82f6",
    },
    {
      id: 2,
      name: "Computer Science",
      members: 8,
      nextSession: "Tomorrow, 2:00 PM",
      progress: 72,
      color: "#8b5cf6",
    },
    {
      id: 3,
      name: "Physics Study Group",
      members: 5,
      nextSession: "Friday, 4:00 PM",
      progress: 65,
      color: "#06b6d4",
    },
    {
      id: 4,
      name: "Literature Review",
      members: 4,
      nextSession: "Saturday, 10:00 AM",
      progress: 90,
      color: "#10b981",
    },
  ];

  const upcomingSessions = [
    {
      id: 1,
      group: "Advanced Mathematics",
      topic: "Calculus Integration",
      time: "Today, 3:00 PM",
      duration: "2 hours",
      status: "upcoming",
    },
    {
      id: 2,
      group: "Computer Science",
      topic: "Data Structures & Algorithms",
      time: "Tomorrow, 2:00 PM",
      duration: "1.5 hours",
      status: "upcoming",
    },
    {
      id: 3,
      group: "Physics Study Group",
      topic: "Quantum Mechanics",
      time: "Friday, 4:00 PM",
      duration: "2 hours",
      status: "scheduled",
    },
  ];

  const recentActivity = [
    {
      id: 1,
      user: "Sarah Johnson",
      action: "completed topic assignment",
      group: "Advanced Mathematics",
      time: "2 hours ago",
    },
    {
      id: 2,
      user: "Mike Chen",
      action: "scheduled a new session",
      group: "Computer Science",
      time: "4 hours ago",
    },
    {
      id: 3,
      user: "Emma Wilson",
      action: "joined the group",
      group: "Literature Review",
      time: "5 hours ago",
    },
    {
      id: 4,
      user: "David Brown",
      action: "shared study materials",
      group: "Physics Study Group",
      time: "Yesterday",
    },
  ];

  const HandelCreateStudy =()=>{
   Nav("/studygroup")
  }
  const HandelInviteMembers =()=>{
   Nav("/addmembers")
  }
  const HandelSess =()=>{
   Nav("/createschedulesess")
  }
const [show,setShow] = useState(false)
const [userSelected,SetuserSelected] = useState({
    data : null,
    
})
const HandelInvite = (data)=>{
 
  SetuserSelected((pre)=>({
    ...pre,
    data : data
  }))
  setShow(true)

}

  return (
    <div className="dashboard-container" >
      {/* Sidebar */}
      <aside className="dashboard-sidebar">
        <div className="sidebar-header">
          <div className="logo-section">
            <BookOpen className="logo-icon" />
            <h2 className="logo-text">StudySync</h2>
          </div>
        </div>

        <nav className="sidebar-nav">
          <button
            className={`nav-item ${activeTab === "overview" ? "active" : ""}`}
            onClick={() => setActiveTab("overview")}
          >
            <TrendingUp size={20} />
            <span>Overview</span>
          </button>
          <button
            className={`nav-item ${activeTab === "groups" ? "active" : ""}`}
            onClick={() => {setActiveTab("my groups")
                Nav("/Mygroups")
            }}
          >
            <Users size={20} />
            <span>My Groups</span>
          </button>
          <button 
            className={`nav-item ${activeTab === "sessions" ? "active" : ""}`}
            onClick={() =>{
                 setActiveTab("Sessions")
                 Nav("/sessionlist")
            }}
          >
            <Calendar size={20} />
            <span >Sessions</span>
          </button>
          <button
            className={`nav-item ${activeTab === "chat" ? "active" : ""}`}
            onClick={() => setActiveTab("chat")}
          >
            <MessageCircle size={20} />
            <span>Messages</span>
          </button>
        </nav>

        <div className="sidebar-footer">
          
          <button className="nav-item" onClick={()=>{
            Nav("/login")
            localStorage.clear()
          }}>
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="dashboard-main">
        {/* Top Bar */}
        <header className="dashboard-header">
          <div className="header-left">
            <button className="menu-button">
              <Menu size={24} />
            </button>
            <div className="search-bar">
              <Search size={20} className="search-icon" />
              <input type="text" placeholder="Search groups, sessions, members..." />
            </div>
          </div>
          <div className="header-right">
            <button className="icon-button">
              <Bell size={20} />
              <span className="notification-badge">5</span>
            </button>
            <div className="user-profile">
              <div className="user-avatar">JD</div>
              <div className="user-info">
                <span className="user-name">{profile?.name}</span>
                <span className="user-role">Student</span>
              </div>
            </div>
          </div>
        </header>

        {/* Stats Grid */}
        <section className="stats-grid">
          {stats.map((stat, index) => (
            <div key={index} className="stat-card">
              <div className="stat-icon">
                <stat.icon size={24} />
              </div>
              <div className="stat-content">
                <p className="stat-label">{stat.label}</p>
                <h3 className="stat-value">{index==0 ? groupxx.length  : stat.value}</h3>
                <p className="stat-change">{stat.change}</p>
              </div>
            </div>
          ))}
        </section>

        {/* Quick Actions */}
        <section className="quick-actions">
          <button className="action-button primary" onClick={()=>HandelCreateStudy()}>
            <Plus size={20} />
            Create Study Group
          </button>
          <button className="action-button" onClick={()=>HandelSess()}>
            <Calendar size={20} />
            Schedule Session
          </button>
         
        </section>

        {/* Content Grid */}
        <div className="content-grid">
          {/* Study Groups */}
          <section className="content-card groups-card">
            <div className="card-header">
              <h2 className="card-title">Your Study Groups</h2>
              <button className="view-all-link">View All</button>
            </div>
            <div className="groups-list">
              {Array.isArray(groupxx) ?
               groupxx?.map((group) => (
                <div key={group.idgroup} className="group-item">
                  <div className="group-color" style={{ backgroundColor: group.color }}></div>
                  <div className="group-info">
                    <h3 className="group-name">{group.name}</h3>
                    <div className="group-meta">
                      <span className="group-members">
                        <Users size={14} /> {1} members
                      </span>
                      <span className="group-session">
                        <Clock size={14} /> {group.datecreate}
                      </span>
                    </div>
                  </div>
                  <div className="group-progress">
                    <div className="progress-bar">
                      <div
                        className="progress-fill"
                        style={{ width: `${85}%`, backgroundColor: "#3b82f6" }}
                      ></div>
                    </div>
                    <span className="progress-text">{89}%</span>
                  </div>
              
                 {group.idgroup ==profile?.uuid &&      <button class="invite-btn" onClick={()=>HandelInvite(group)}>Invite</button> }

                  <button class="invite-btn" onClick={()=>Nav(`/mygroups/${group.identify}`)}>join</button> 
                </div>
              )) : <div style={{
                display:"flex",
                justifyContent:"center",
                marginTop:"100px"
              }}>
          <Loader1/>              
              </div>}
            </div>
          </section>

          {/* Upcoming Sessions */}
          <section className="content-card sessions-card">
            <div className="card-header">
              <h2 className="card-title">Upcoming Sessions</h2>
              <button className="view-all-link">View Calendar</button>
            </div>
            <div className="sessions-list">
              {upcomingSessions.map((session) => (
                <div key={session.id} className="session-item">
                  <div className="session-time">
                    <Calendar size={20} />
                  </div>
                  <div className="session-info">
                    <h3 className="session-topic">{session.topic}</h3>
                    <p className="session-group">{session.group}</p>
                    <div className="session-meta">
                      <span className="session-datetime">
                        <Clock size={14} /> {session.time}
                      </span>
                      <span className="session-duration">{session.duration}</span>
                    </div>
                  </div>
                  <button className="join-button">
                    {session.status === "upcoming" ? "Join" : "Details"}
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* Recent Activity */}
          <section className="content-card activity-card">
            <div className="card-header">
              <h2 className="card-title">Recent Activity</h2>
              <button className="view-all-link">View All</button>
            </div>
            <div className="activity-list">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="activity-item">
                  <div className="activity-avatar">{activity.user.charAt(0)}</div>
                  <div className="activity-info">
                    <p className="activity-text">
                      <strong>{activity.user}</strong> {activity.action}
                    </p>
                    <p className="activity-group">{activity.group}</p>
                  </div>
                  <span className="activity-time">{activity.time}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Progress Overview */}
          <section className="content-card progress-card">
            <div className="card-header">
              <h2 className="card-title">Your Progress</h2>
            </div>
            <div className="progress-overview">
              <div className="progress-circle">
                <svg viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="45" className="progress-bg" />
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    className="progress-circle-fill"
                    style={{ strokeDashoffset: 283 - (283 * 78) / 100 }}
                  />
                </svg>
                <div className="progress-percentage">78%</div>
              </div>
              <div className="progress-stats">
                <div className="progress-stat">
                  <CheckCircle size={20} className="stat-icon-check" />
                  <div>
                    <p className="stat-number">24</p>
                    <p className="stat-label-small">Topics Completed</p>
                  </div>
                </div>
                <div className="progress-stat">
                  <BookOpen size={20} className="stat-icon-book" />
                  <div>
                    <p className="stat-number">8</p>
                    <p className="stat-label-small">Active Topics</p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
     
      {show  &&  <Addmembers data = {userSelected} fn ={setShow}  />  }

    </div>
  );
};

export default Dashboard;
