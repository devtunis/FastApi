import { useEffect, useState } from "react";
import "./Sessionlist.css";

const Sessionslist = () => {
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("sessions")) || [];
    setSessions(saved);
  }, []);

  return (
    <div className="sessions-container">
      <h1>Scheduled Sessions</h1>
      <p>Your upcoming study sessions</p>

      {sessions.length === 0 ? (
        <div className="empty-box">
          No sessions created yet.
        </div>
      ) : (
        <div className="sessions-grid">
          {sessions.map((sess) => (
            <div className="session-card" key={sess.id}>
              <h2>{sess.title}</h2>

              <div className="session-info">
                <p><span>📅 Date:</span> {sess.date}</p>
                <p><span>⏰ Time:</span> {sess.time}</p>
                <p><span>📍 Location:</span> {sess.location}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Sessionslist;