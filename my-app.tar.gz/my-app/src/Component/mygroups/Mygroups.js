import { useNavigate, useParams } from "react-router";
import "./Mygroups.css";
import { useEffect  , useState   } from "react";
 
 
import axios from "axios";
import { time } from "../../utils/time";

const Mygroups = () => {

    useEffect(()=>{
    const data = localStorage.getItem("profile")
    if(!data){
      Nav("/login")
    }
  },[])
 
  const [profile] = useState(()=>JSON.parse(localStorage.getItem("profile")))
  
  const Nav = useNavigate()
 
  const parms = useParams()
  const [date,setdate] = useState(null)
  const [state , SetUseState] = useState({
    taskname : '',
    content  : ''
  })
  const [ListOfTasks , SetListOfTasks] = useState([])

  useEffect(()=>{
    const fetchrepo = async()=>{
      try{
          const {data} =  await axios.get(`http://127.0.0.1:8000/session/${parms.id}`)
          console.log(data)
          setdate(data)
      }catch(err){
        console.log(err)
      }
    }

    fetchrepo()
  },[])


  useEffect(()=>{
    const fetchrepo2 = async()=>{
      try{
          const {data} =  await axios.get(`http://127.0.0.1:8000/tasks/${parms.id}`)
           if(Array.isArray(data))
           {
            SetListOfTasks(data) 
           }
        
      }catch(err){
        console.log(err)
      }
    }

    fetchrepo2()
  },[])




  const CreateContent = async () =>{

   if(state.taskname==='' || state.content===''){
    alert("empty filed")
   }
   
     try{
          const data = await axios.post(`http://127.0.0.1:8000/tasks`,{
            "identify" : date.identify,
            "Date":time(),
            "content" : state.content,
            "nametask":state.taskname
          })
          if(data){
            console.log("suuces")
            SetListOfTasks((prev)=>[...prev,{identify :date.identify , Date : time() ,content:state.content , nametask : state.taskname}])
            Setshow(false)
          }
     }catch(err){
      console.log(err)
     }
  }
  const [show,Setshow] = useState(false)
  const HandelDeleteGrouo =async (id,identify)=>{
    
     try{
      const {data} = await axios.post(`http://127.0.0.1:8000/tasks/delete/${id}/${identify}`)
      if(data){
        
        SetListOfTasks(data.alltask)
      }

     }catch(error){
      console.log(error)
     }
  }
  return (

    <>
    
    <button className="task-add" onClick={()=>Setshow((fn)=>!fn)}>Add Task</button>
    
        <div className="groups-container" onClick={()=>Setshow(false)}>
      <h1>My Groups</h1>
      <h1>{date?.datecreate}</h1>
      <p>Topic : {date?.topic}</p>
      <p>Content : {date?.content}</p>
      <p>All your study groups in one place</p>

      <div className="groups-grid">
        { ListOfTasks.length>0  &&  ListOfTasks.map((group) => (
          //  onClick={()=>Nav(`/mygroupsession/:${group.id}`)}
          <div className="group-card" key={group.taskId} >
            <div 
            onClick={()=>HandelDeleteGrouo(group.taskId , group.identify)}
            
            style={{padding:"6px",background:"green",cursor:"pointer",borderRadius:"100%" ,position:"absolute",top:"0" , right:"0" , marginTop:"10px",marginRight:"5px"}}></div>
            <h2 className="group-name" style={{textAlign:"center"}}>{group.nametask}</h2>

            <div className="group-info">
              <p>
                <span>📅 Date:</span> {group.Date}
              </p>
              <p>
                <span>📝 TASK:</span>  {group.content}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>


{

  show  &&       <div className="form-container">
      <label className="form-label">TASK NAME</label>
      <input className="form-input" onChange={(e)=>SetUseState({
        ...state,
        taskname : e.target.value
      })} placeholder="Enter TASK name" />

      <label className="form-label"  >Content</label>
      <input className="form-input" 
      onChange={(e)=>SetUseState({
        ...state,
        content:e.target.value
      })}      
      placeholder="Enter Content" />

      <button className="form-button" onClick={()=>CreateContent()}>Create Content</button>
    </div>

}

    
 

</>

  );
};

export default Mygroups;