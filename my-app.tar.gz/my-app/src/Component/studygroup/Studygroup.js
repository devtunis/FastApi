import {  useEffect, useState } from "react";
import "./Studygroup.css";
import axios from "axios";
import { randochr } from "../../utils/randochr";
import { useNavigate } from "react-router";

const Studygroup = () => {
  const Nav = useNavigate()
  useEffect(()=>{
    const test = localStorage.getItem("profile")
    if(!test){
      Nav("/login")
    }
  },[])
  const [Profile] = useState(()=>JSON.parse(localStorage.getItem("profile")))
  const [form, setForm] = useState({
    groupName: "",
    topic: "",
    subject: "",
    description: "",
    maxMembers: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit =  async(e) => {
    e.preventDefault();
 
 
    try{
      const  instance = new Date()
      const datex = `${instance.getFullYear()}-${instance.getMonth()}-${instance.getDay()}-${instance.getMilliseconds()}`
      const identifyuuid = randochr()  
      const {data} = await axios.post('http://127.0.0.1:8000/Creategroup',{
          "idgroup": Profile.uuid,
          "namegroup": form.groupName,
          "topic": form.topic,
          "datecreate": datex ,
          "contentgroup": form.description,
          "identify":identifyuuid
        })
    if(data){
      console.log("create group avec succes")
      const addingyou = await axios.post("http://127.0.0.1:8000/addMember",{
        "userid": Profile.uuid, 
        "groupid": Profile.uuid  ,
        "identify" :identifyuuid ,
        "Date" : datex
    })
    if(addingyou){
      console.log("we insert you in the group")
      Nav("/dashboard")
    }
    }

    }catch(error){
      console.log(error)
    }
  };

  return (
    <div className="studygroup-container">
      <form className="studygroup-form" onSubmit={handleSubmit}>
        <h1>Create Study Group</h1>
        <p>Fill in the details to create your group</p>

        <label>Group Name</label>
        <input
          type="text"
          name="groupName"
          placeholder="e.g. Advanced Mathematics"
          value={form.groupName}
          onChange={handleChange}
          required
        />

        <label>Topic</label>
        <input
          type="text"
          name="topic"
          placeholder="e.g. Calculus, Algebra"
          value={form.topic}
          onChange={handleChange}
          required
        />

        <label>Subject</label>
        <input
          type="text"
          name="subject"
          placeholder="e.g. Math, Physics"
          value={form.subject}
          onChange={handleChange}
        />

        <label>Description</label>
        <textarea
          name="description"
          placeholder="Describe your study group..."
          value={form.description}
          onChange={handleChange}
          rows="4"
        />

        

        <button type="submit">Create Group</button>
      </form>
    </div>
  );
};

export default Studygroup;