import { Routes,Route } from "react-router"
import Login from "./Component/login/Login"
import Register from "./Component/register/Register"
import Dashboard from "./Component/dashboard/Dashboard"
import Studygroup from "./Component/studygroup/Studygroup"
import Addmembers from "./Component/addmembers/Addmembers"
import CreateSchedulesess from "./Component/schedulesess/CreateSchedulesess"
 
import Mygroups from "./Component/mygroups/Mygroups"
import Sessionslist from "./Component/sessionlist/Sessionlist"
import Mygroupsession from "./Component/mygroupsession/Mygroupsession"

 
const App  = ()=>{
  return(
    <Routes>
      <Route path="/login" element={<Login/>}/>
       <Route path="/" element={<p>hello home</p>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/dashboard" element={<Dashboard/>}/>
        <Route path="/studygroup" element={<Studygroup/>}/>
        {/* <Route path="/addmembers" element={<Addmembers/>}/> */}
        <Route path="/createschedulesess" element={<CreateSchedulesess/>}/>
        <Route path="/sessionlist" element={<Sessionslist/>}/>
        <Route path="/mygroups/:id" element={<Mygroups/>}/>
        <Route path="/mygroupsession/:idroom" element={<Mygroupsession/>}/>


    </Routes>
  )
}

export default App